# easeui
####EaseUI是一个基于环信sdk的UI库，封装了IM功能常用的控件、fragment等等。此项目包含一个简单使用的demo：simpledemo，开发者可导出查看。
####github上的代码不包含环信sdk，clone使用时需要把环信sdk所需的jar包，so等等拷贝进来。



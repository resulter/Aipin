var searchData=
[
  ['message_5fencryption_5ferror',['MESSAGE_ENCRYPTION_ERROR',['../classcom_1_1hyphenate_1_1_e_m_error.html#a6669df2ee9de1d0dc6231427a28b683a',1,'com::hyphenate::EMError']]],
  ['message_5finclude_5fillegal_5fcontent',['MESSAGE_INCLUDE_ILLEGAL_CONTENT',['../classcom_1_1hyphenate_1_1_e_m_error.html#a899d93b56c503bea06165d42ff2b0647',1,'com::hyphenate::EMError']]],
  ['message_5finvalid',['MESSAGE_INVALID',['../classcom_1_1hyphenate_1_1_e_m_error.html#afea45a5fbac3a4a40f3a2d24d092aecb',1,'com::hyphenate::EMError']]],
  ['message_5fsend_5ftraffic_5flimit',['MESSAGE_SEND_TRAFFIC_LIMIT',['../classcom_1_1hyphenate_1_1_e_m_error.html#a35cdce147efc8c840242791e6206d215',1,'com::hyphenate::EMError']]],
  ['messageid',['MessageId',['../enumcom_1_1hyphenate_1_1_e_m_message_change_event_data_1_1_e_m_change_source.html#acc8b9b31f5a864c67ad5dba8c7f6ed82',1,'com::hyphenate::EMMessageChangeEventData::EMChangeSource']]],
  ['messagestate',['MessageState',['../enumcom_1_1hyphenate_1_1_e_m_message_change_event_data_1_1_e_m_change_source.html#ac542b0adaab1b78b18ec2f5bb45aae34',1,'com::hyphenate::EMMessageChangeEventData::EMChangeSource']]]
];

var searchData=
[
  ['fetchchatroomfromserver',['fetchChatRoomFromServer',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_chat_room_manager.html#abe65c32b2b9c856a70501418bea203ce',1,'com.hyphenate.chat.EMChatRoomManager.fetchChatRoomFromServer(String roomId)'],['../classcom_1_1hyphenate_1_1chat_1_1_e_m_chat_room_manager.html#a7576492c348f89ede237f3cc8ef0df86',1,'com.hyphenate.chat.EMChatRoomManager.fetchChatRoomFromServer(String roomId, boolean fetchMembers)']]],
  ['fetchpublicchatroomsfromserver',['fetchPublicChatRoomsFromServer',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_chat_room_manager.html#a736a13beebf61bd5ccca2695a3fc9cd9',1,'com::hyphenate::chat::EMChatRoomManager']]]
];

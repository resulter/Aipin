var searchData=
[
  ['pinyins',['PINYINS',['../classcom_1_1hyphenate_1_1util_1_1_hanzi_to_pinyin.html#ac4ead11f15e8bf3015482c0f4160d6d2',1,'com::hyphenate::util::HanziToPinyin']]]
];

var searchData=
[
  ['video',['video',['../enumcom_1_1hyphenate_1_1chat_1_1_e_m_call_manager_1_1_e_m_video_call_helper_1_1_call_type.html#a5f6864b667109124174e04f0ae785c37',1,'com::hyphenate::chat::EMCallManager::EMVideoCallHelper::CallType']]],
  ['voicerecorder',['VoiceRecorder',['../classcom_1_1hyphenate_1_1util_1_1_voice_recorder.html',1,'com::hyphenate::util']]]
];

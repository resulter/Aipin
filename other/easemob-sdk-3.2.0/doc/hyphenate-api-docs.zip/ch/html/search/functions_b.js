var searchData=
[
  ['makevideocall',['makeVideoCall',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_call_manager.html#a3e49344c1ff527960e8978f2ba6858db',1,'com::hyphenate::chat::EMCallManager']]],
  ['makevoicecall',['makeVoiceCall',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_call_manager.html#ab18d852e3ce41debf25142b69ff04cf5',1,'com::hyphenate::chat::EMCallManager']]],
  ['markallconversationsasread',['markAllConversationsAsRead',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_chat_manager.html#a4f7dbf5b36fadde636db34dfaa7fc41f',1,'com::hyphenate::chat::EMChatManager']]],
  ['markmessageasread',['markMessageAsRead',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_conversation.html#a9e542e10f41e0c7f84d9fac97d03b3fd',1,'com::hyphenate::chat::EMConversation']]],
  ['mergeimages',['mergeImages',['../classcom_1_1hyphenate_1_1util_1_1_image_utils.html#adfa747e9784a9a4cb5b6ffef0f249524',1,'com::hyphenate::util::ImageUtils']]],
  ['msgtype2conversationtype',['msgType2ConversationType',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_conversation.html#a2af3c651b5402f316fea84d97bf5e1eb',1,'com::hyphenate::chat::EMConversation']]]
];
